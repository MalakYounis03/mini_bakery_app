import 'package:flutter/material.dart';

class CategoryShopPage extends StatelessWidget {
  const CategoryShopPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
